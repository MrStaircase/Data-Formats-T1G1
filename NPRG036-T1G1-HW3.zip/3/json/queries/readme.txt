The 1st query returns the names of employees who work at shops that have a capacity greater than 20, and the count of products they make.

The 2nd query returns all shops that produce at least one product that have price greater than 20, and the names of those products.

The 3rd query, for every person (Employees and Customers), lists their full name, a bool which is true if the person has at least one phone number, and a quantity of the phone numbers the person has.

The 4th query lists each Employee's full name and how many products the employee produces.
